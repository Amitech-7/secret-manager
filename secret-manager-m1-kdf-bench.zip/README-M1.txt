M1 step 1: Argon2id key derivation + phone benchmark.
Extract over the repo root (overwrite), then delete packages/crypto/src/index.test.ts and run pnpm install.
