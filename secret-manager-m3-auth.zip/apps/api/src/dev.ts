import { serve } from '@hono/node-server'
import app from './handler'

const port = Number(process.env.PORT ?? 8787)
serve({ fetch: app.fetch, port })
console.log(`API listening on http://localhost:${port}/api/v1/health`)
